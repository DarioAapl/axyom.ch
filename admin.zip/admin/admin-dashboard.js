const API = "https://api.axyom.ch";

function normalizeDomain(input) {
  input = input.trim();

  // Remove http:// or https://
  input = input.replace(/^https?:\/\//, "");

  // Remove trailing slash only
  input = input.replace(/\/$/, "");

  return input;
}

/* ============================
   DEPLOY INFO (SET ON LOAD)
============================ */
document.addEventListener("DOMContentLoaded", async () => {
  const deployEl = document.getElementById("deployInfo");
  if (!deployEl) return;

  try {
    const res = await fetch(`${API}/deploy-info`);
    const data = await res.json();

    const date = new Date(data.deploy_time);

    const formatted = date.toLocaleString(undefined, {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      timeZoneName: "short"
    });

    deployEl.textContent = "Deploy: " + formatted;

  } catch (e) {
    deployEl.textContent = "Deploy: Unknown";
  }
});

/* ============================
   AUTH HELPERS
============================ */
function getToken() {
  return localStorage.getItem("admin_token");
}

function authHeaders() {
  return {
    Authorization: `Bearer ${getToken()}`
  };
}

function logout() {
  localStorage.removeItem("admin_token");
  localStorage.removeItem("admin_email");
  window.location.href = "admin.html";
}

/* ============================
   INIT (PROTECT PAGE)
============================ */
(async function init() {
  if (!getToken()) return logout();

  const test = await fetch(`${API}/admin/customers`, {
    headers: authHeaders(),
  });

  if (!test.ok) return logout();

  const emailEl = document.getElementById("adminEmail");
  if (emailEl) {
    emailEl.textContent = localStorage.getItem("admin_email");
  }

  await loadCustomers();
  await loadKeys();
  await loadWebsites();
})();

/* ============================
   PROGRESS BAR
============================ */

const progressIntervals = {};

function progressBar(id) {
  return `
    <div id="progress-${id}" class="progress-container" style="display:none">
      <div class="progress-bar">
        <div id="progress-fill-${id}" class="progress-fill"></div>
      </div>
      <span id="progress-text-${id}" class="progress-text">0%</span>
    </div>
  `;
}

function startProgress(id) {
  const container = document.getElementById(`progress-${id}`);
  const fill = document.getElementById(`progress-fill-${id}`);
  const text = document.getElementById(`progress-text-${id}`);

  if (!container || !fill || !text) return;

  container.style.display = "inline-flex";

  let percent = 0;

  progressIntervals[id] = setInterval(() => {
    if (percent < 95) {
      percent += Math.random() * 4;
      percent = Math.min(percent, 95);
      fill.style.width = percent + "%";
      text.textContent = Math.floor(percent) + "%";
    }
  }, 400);
}

function finishProgress(id) {
  const fill = document.getElementById(`progress-fill-${id}`);
  const text = document.getElementById(`progress-text-${id}`);
  const container = document.getElementById(`progress-${id}`);

  if (progressIntervals[id]) {
    clearInterval(progressIntervals[id]);
    delete progressIntervals[id];
  }

  if (fill && text) {
    fill.style.width = "100%";
    text.textContent = "100%";
  }

  setTimeout(() => {
    if (container) container.style.display = "none";
  }, 600);
}

/* ============================
   CUSTOMERS
============================ */
async function loadCustomers() {
  const res = await fetch(`${API}/admin/customers`, {
    headers: authHeaders(),
  });

  const data = await res.json();
  document.getElementById("statCustomers").textContent = data.length;

  const tbody = document.getElementById("customersTable");
  tbody.innerHTML = "";

  data.forEach(c => {
    tbody.innerHTML += `
      <tr>
        <td>${c.id}</td>
        <td>${c.email}</td>
        <td>${c.is_active ? "Active" : "Disabled"}</td>
        <td>${new Date(c.created_at).toLocaleString()}</td>
        <td>
          <button class="btn danger small"
            onclick="deleteCustomer(${c.id})">
            Delete
          </button>
          ${progressBar("customer-" + c.id)}
        </td>
      </tr>
    `;
  });
}

async function deleteCustomer(id) {
  if (!confirm("Delete this customer and ALL their websites?")) return;

  startProgress("customer-" + id);

  const res = await fetch(`${API}/admin/customers/${id}`, {
    method: "DELETE",
    headers: authHeaders(),
  });

  finishProgress("customer-" + id);

  if (!res.ok) {
    alert("Delete failed");
    return;
  }

  await loadCustomers();
  await loadWebsites();
  await loadKeys();
}

/* ============================
   API KEYS
============================ */
async function loadKeys() {
  const res = await fetch(`${API}/admin/keys`, {
    headers: authHeaders(),
  });

  const data = await res.json();
  document.getElementById("statKeys").textContent = data.length;

  const tbody = document.getElementById("keysTable");
  tbody.innerHTML = "";

  data.forEach(k => {
    tbody.innerHTML += `
      <tr>
        <td>${k.id}</td>
        <td class="mono">${k.key}</td>
        <td>${k.domain}</td>
        <td>${k.is_active ? "Active" : "Revoked"}</td>
        <td>${new Date(k.created_at).toLocaleString()}</td>
        <td>
          <button class="btn small"
            onclick="copyEmbed('${k.key}')">
            📋 Copy
          </button>
        </td>
      </tr>
    `;
  });
}

/* ============================
   COPY EMBED SCRIPT
============================ */
function copyEmbed(apiKey) {
  const script = `
<!-- AXYOM AI -->
<script>
  window.AXYOM_KEY = "${apiKey}";
</script>
<script src="https://api.axyom.ch/widget/axyom.js" async></script>
`.trim();

  navigator.clipboard.writeText(script)
    .then(() => alert("Embed script copied."))
    .catch(() => alert("Copy failed."));
}

/* ============================
   WEBSITES
============================ */
async function loadWebsites() {
  const res = await fetch(`${API}/admin/websites`, {
    headers: authHeaders(),
  });

  const websites = await res.json();
  const table = document.getElementById("websitesTable");
  table.innerHTML = "";

  websites.forEach(w => {
    const analysis = w.analysis;

    let verdictBadge = `<span class="pill muted">Not analyzed</span>`;
    let actionBtn = "";

    if (analysis) {
      const color =
        analysis.verdict === "ok" ? "green" :
        analysis.verdict === "too_big" ? "red" :
        analysis.verdict === "too_small" ? "orange" :
        "gray";

      verdictBadge = `
        <span class="pill ${color}">
          ${analysis.verdict.toUpperCase()}
        </span>
      `;
    }

    if (w.is_trained) {
      actionBtn = `<span class="pill green">Trained</span>`;
    } else if (!analysis) {
      actionBtn = `
        <button class="btn small"
          onclick="analyzeWebsite(${w.id})">
          Analyze
        </button>
      `;
    } else if (analysis.verdict === "ok") {
      actionBtn = `
        <button class="btn primary small"
          onclick="trainWebsite(${w.id})">
          Train
        </button>
      `;
    } else {
      actionBtn = `
        <button class="btn ghost small"
          onclick="trainWebsite(${w.id}, true)">
          Force Train
        </button>
      `;
    }

    table.innerHTML += `
      <tr>
        <td>${w.id}</td>
        <td>${w.domain}</td>
        <td>${verdictBadge}</td>
        <td>
          ${analysis ? `
            <div class="meta">
              ${analysis.estimated_pages} pages ·
              ${analysis.estimated_chunks} chunks
            </div>
          ` : `<span class="muted">—</span>`}
        </td>
        <td>
          ${actionBtn}

          <button class="btn ghost small"
            onclick="inspectWebsite(${w.id})">
            Inspect
          </button>

          <button class="btn danger small"
            onclick="deleteWebsite(${w.id})">
            Delete
          </button>

          ${progressBar(w.id)}
        </td>
      </tr>
    `;
  });
}

/* ============================
   ANALYZE WEBSITE
============================ */
async function analyzeWebsite(id) {
  if (!confirm("Analyze this website first?")) return;

  startProgress(id);

  const res = await fetch(`${API}/admin/websites/${id}/analyze`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(),
    },
    body: JSON.stringify({}),
  });

  finishProgress(id);

  if (!res.ok) {
    alert("Analyze failed");
    return;
  }

  await loadWebsites();
}

/* ============================
   TRAIN WEBSITE
============================ */
async function trainWebsite(id, force = false) {
  const customUrl = prompt(
    "Enter full URL to train.\nLeave empty to train entire domain:"
  );

  const msg = force
    ? "Force training despite warnings?"
    : "Train now?";

  if (!confirm(msg)) return;

  startProgress(id);

  const res = await fetch(`${API}/admin/websites/${id}/train`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(),
    },
    body: JSON.stringify({
      force,
      url: customUrl && customUrl.trim() !== "" ? customUrl.trim() : null
    }),
  });

  finishProgress(id);

  if (!res.ok) {
    alert("Training failed");
    return;
  }

  await loadWebsites();
}

/* ============================
   DELETE WEBSITE
============================ */
async function deleteWebsite(id) {
  if (!confirm("Delete this website permanently?")) return;

  startProgress(id);

  const res = await fetch(`${API}/admin/websites/${id}`, {
    method: "DELETE",
    headers: authHeaders(),
  });

  finishProgress(id);

  if (!res.ok) {
    alert("Delete failed");
    return;
  }

  await loadWebsites();
  await loadKeys();
}

/* ============================
   CREATE KEY
============================ */
async function createKey() {
  const email = document.getElementById("newEmail").value.trim();
  const rawDomain = document.getElementById("newDomain").value;
  const domain = normalizeDomain(rawDomain);

  if (!domain) return alert("Domain required");

  await fetch(`${API}/admin/create-key`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(),
    },
    body: JSON.stringify({ email, domain }),
  });

  document.getElementById("createKeyMsg").textContent = "API key created";
  document.getElementById("newDomain").value = "";
  await loadKeys();
}

/* ============================
   INSPECT WEBSITE
============================ */
async function inspectWebsite(id) {
  try {
    startProgress(id);

    const res = await fetch(`${API}/admin/websites/${id}/inspect`, {
      headers: authHeaders(),
    });

    finishProgress(id);

    if (res.status === 401) {
      logout();
      return;
    }

    if (!res.ok) {
      const text = await res.text();
      console.error("Inspect failed:", text);
      alert("Inspect failed");
      return;
    }

    const data = await res.json();
    console.log("INSPECT RESPONSE:", data);

    if (!data || typeof data !== "object") {
      alert("Inspect returned empty response.");
      return;
    }

    // Build modal-style output
    let message = `
INSPECT RESULT

Intent: ${data.intent ?? "N/A"}
Confidence: ${data.confidence ?? "N/A"}

Notes:
${data.notes ?? "None"}
`;

    if (data.all_chunks_text) {
      const shouldCopy = confirm(
        message +
        "\n\nPress OK to copy ALL CHUNKS to clipboard.\nPress Cancel to just close."
      );

if (data.all_chunks_text) {
  const shouldDownload = confirm(
    message +
    "\n\nPress OK to download ALL CHUNKS as a .txt file.\nPress Cancel to just close."
  );

  if (shouldDownload) {
    try {
      const blob = new Blob([data.all_chunks_text], { type: "text/plain" });
      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = `axyom_chunks_${id}.txt`;
      document.body.appendChild(a);
      a.click();

      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      alert("Chunks downloaded.");
    } catch (e) {
      console.error("Download failed:", e);
      alert("Download failed. Check console.");
    }
  }
} else {
  alert(message);
}
    } else {
      alert(message);
    }

  } catch (err) {
    finishProgress(id);
    console.error("Inspect crashed:", err);
    alert("Inspect crashed. Check console.");
  }
}